export const Users =  

    [
        {
          "name":"Uchiha shisui",
          "role":"UX Engineer"
        },
        {
            "name":"Tory Lanez",
            "role":"UX Engineer"
          },
        {
        "name":"Gon Freecs",
        "role":"UX Engineer"
        },
        {
            "name":"Ichigo Kurosaki",
            "role":"UX Engineer"
          },
          {
            "name":"Eren Jeager",
            "role":"UX Engineer"
          },
          {
            "name":"Yuuji Itadori",
            "role":"UX Engineer"
          },{
            "name":"Shinsuke Nakamura",
            "role":"UX Engineer"
          },{
            "name":"Naruto Uzumaki",
            "role":"UX Engineer"
          },{
            "name":"Didier Drogba",
            "role":"UX Engineer"
          },
          {
            "name":"Michael Ballack",
            "role":"UX Engineer"
          },
    ]
    
